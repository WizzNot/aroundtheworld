package com.example.project.server_data;

public class config {
    public static final String DB_URL = "https://ohhwf.localto.net/";
    public static final String VK_API_URL = "https://api.vk.com";
}
