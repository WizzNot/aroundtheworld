package com.example.project.main;

import static com.example.project.server_data.ServiceConstructor.CreateService;
import static com.example.project.server_data.config.DB_URL;
import static com.example.project.server_data.config.VK_API_URL;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.project.server_data.Data;
import com.example.project.server_data.Service;
import com.example.project.server_data.VkResponse;
import com.vk.api.sdk.VK;
import com.vk.api.sdk.auth.VKAccessToken;
import com.vk.api.sdk.auth.VKAuthCallback;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class vkAUTH extends Activity {
    Button vkAuth;
    public static final String APP_PREFERENCES = "mysettings";
    public static final String APP_PREFERENCES_PHONE = "PHONE";
    SharedPreferences mSettings;
    int ind = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThreadRequestVk threadRequestVk = new ThreadRequestVk();
        threadRequestVk.start();
        Log.d("verification_1", "1");
        mSettings = vkAUTH.this.getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        Log.d("verification_1", mSettings.getString(APP_PREFERENCES_PHONE, ""));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (!VK.onActivityResult(requestCode, resultCode, data, new VKAuthCallback() {
            @Override
            public void onLogin(@NonNull VKAccessToken vkAccessToken) {
                Log.d("vkAuth_123", "onLogin");
                To_verif to_verif = new To_verif(vkAccessToken);
                to_verif.start();
                try {
                    to_verif.join();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                Mythread mythread = new Mythread(vkAccessToken);
                mythread.start();
                startActivity(new Intent(vkAUTH.this, MainActivity.class));
            }
            @Override
            public void onLoginFailed(int i) {
                Log.d("vkAuth_123", "onLoginFailed");
                startActivity(new Intent(vkAUTH.this, MainActivity.class));
            }
        })) super.onActivityResult(requestCode, resultCode, data);
    }
    class ThreadRequestVk extends Thread{
        @Override
        public void run() {
            VK.login(vkAUTH.this);
        }
    }
    class Mythread extends Thread{
        VKAccessToken vkAccessToken;
        Mythread(VKAccessToken vkAccessToken){
            this.vkAccessToken = vkAccessToken;
        }
        @Override
        public void run() {
            Data data = new Data();
            data.setMode("verification");
            data.setVkAccessToken(vkAccessToken.getAccessToken());

            To_verif to_verif = new To_verif(vkAccessToken);
            to_verif.start();
            Log.d("verification_1", "thread_run");
            if (ind == 2){
                data.setVerification("2");
            } else data.setVerification("1");
            Log.d("verification_1", mSettings.getString(APP_PREFERENCES_PHONE, ""));
            data.setNumber(mSettings.getString(APP_PREFERENCES_PHONE, ""));
            Call<Data> call = CreateService(Service.class, DB_URL).give_date(data);
            call.enqueue(new Callback<Data>() {
                @Override
                public void onResponse(Call<Data> call, Response<Data> response) {
                    if (response.isSuccessful()) {
                        Log.d("verification_1", "response is successful");
                    } else Log.d("verification_1", "response is NOT successful");
                }
                @Override
                public void onFailure(Call<Data>call, Throwable t) {
                    Log.d("verification_1", "onFailure");
                }
            });
        }
    }
    class To_verif extends Thread{
        VKAccessToken vkAccessToken;
        To_verif(VKAccessToken vkAccessToken){
            this.vkAccessToken = vkAccessToken;
        }

        @Override
        public void run() {
            Log.d("verification_2", "thread_run");
            Call<VkResponse> call = CreateService(Service.class, VK_API_URL).vkRequest("users.get", vkAccessToken.getAccessToken(), "oauth_verification", "5.204");
            call.enqueue(new Callback<VkResponse>() {
                @Override
                public void onResponse(Call<VkResponse> call, Response<VkResponse> response) {
                    if (response.isSuccessful()) {
                        Log.d("verification_2", "response is successful");
                        if (response.body().getResponse().get(0).getOauth_verification().isEmpty()){
                            ind = 1;
                        } else {
                            ind = 2;
                        }
                        Log.d("verification_2", response.body().toString());
                    } else Log.d("verification_2", "response is NOT successful");
                }
                @Override
                public void onFailure(Call<VkResponse>call, Throwable t) {
                    Log.d("verification_2", "onFailure");
                }
            });
        }
    }
}















